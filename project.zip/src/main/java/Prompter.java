import java.util.Scanner;

class Prompter{
  
      private String itemName;
      private String maxSItems;
      private int maxItems;
      public static int playerGuess;
      private int howManyGuesses = 0;

      Scanner scanner = new Scanner(System.in);
      Jar jar = new Jar();        

      //Requests item name from admin.   
      public String getItem(){
        System.out.printf("%n================%nADMINISTRATOR%n================%n");      
        System.out.printf("What type of item? ");
        itemName = scanner.nextLine();
        return itemName;
      }
  
      //Requests maximum amount of items from admin.
      public int getMaxItems(){  
        System.out.printf("What is the maximum amount of %s? ", itemName);
        maxSItems = scanner.nextLine();
        this.maxItems = Integer.parseInt(maxSItems);
        return this.maxItems;
      }  
  
      //Starts player interaction.
      public void playerAction(){
        System.out.printf("%n================%nPLAYER%n================%n");
        System.out.printf("How many %s are in the jar? Pick a number between 1 and %d.%n", itemName, maxItems);
      }
  
      //Here the player will be asked for and handles the logic of guesses. 
      public void getGuess(){
        do {
          //This will make sure to loop until the player provides a number which is less than maxItems.
          do{
            System.out.printf("Provide a guess: ");
            playerGuess = scanner.nextInt();
            if (playerGuess > maxItems){
              System.out.printf("Your guess must be less than "+maxItems+"%n");
            }
          }while (playerGuess > maxItems);
          //For each time the player puts in a valid guess add +1 to howManyGuesses counter.
          howManyGuesses++;
          //This is to help the player by pointing if guess is too high or low.
          if(playerGuess > jar.howFull){            
            System.out.printf("Your guess is too high%n");
          } else if (playerGuess < jar.howFull){
            System.out.printf("Your guess is too low%n");
          }
        //This will ensure a win condition otherwise continue repeating.    
        } while(playerGuess != jar.howFull);
      }
  
      //Prompt the player that they have won and how many tries.
      public void playerWins(){
        System.out.printf("================%nCongratulations!%n================%n");
        System.out.printf("You got it in %s attempts %n", howManyGuesses);
      }
   
  }