import java.util.Random;

public class Jar {
  private String itemName;
  private int maxItems;
  public static int howFull;
  Random random = new Random();
  
  public Jar (){
  }
  
  //Constructor for Jar which takes the item name and maximum amount of Items provided by the administrator in the main.
  public Jar (String itemName, int maxItems){
    this.itemName = itemName;
    this.maxItems = maxItems;
  }
  //Based on the maxItems it will set a random number between 1 and maxItems.
  public void fill (int maxItems){
    this.howFull = random.nextInt(maxItems)+1;
  }

    
    
    
  

  
  
  
} 