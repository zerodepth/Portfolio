
public class GuessingGame {
    public static void main(String[] args) {

      Prompter prompter = new Prompter();
      
      //Administrator provides item name and maximum amount of items.
      String itemName = prompter.getItem();
      int maxItems = prompter.getMaxItems();
      
      //Here we create a new Jar object and fill it with a random number of items, between 1 to the maximum amount of items provided by the admin.
      Jar jar = new Jar(itemName, maxItems);
      jar.fill(maxItems);
      
      //Here we provide the user with the scenario and request the player to provide guesses.
      prompter.playerAction();
      prompter.getGuess();
      
      //If the player guesses equal the random number player wins the game.
      if (prompter.playerGuess == jar.howFull){
        prompter.playerWins();
      }  
    }
}
